import static spark.Spark.*;
public class JavaService {
    public static void main(String[] args) {
        port(9003);
        get("/java", (req, res) -> "Hello World from Java");
    }
}