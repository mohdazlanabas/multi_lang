<?php
if ($_SERVER['REQUEST_URI'] === '/php') {
  echo "Hello World from PHP";
}
?>