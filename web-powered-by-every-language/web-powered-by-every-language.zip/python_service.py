from flask import Flask
app = Flask(__name__)
@app.route("/python")
def msg():
    return "Hello World from Python"
app.run(port=9001)