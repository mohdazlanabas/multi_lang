const languages = [
  "python", "javascript", "java", "php", "dart", "go", 
  "rust", "c", "cpp", "csharp", "typescript", "lua", 
  "fortran", "cobol", "pascal"
];

const messagesDiv = document.getElementById("messages");

languages.forEach(lang => {
  fetch(`http://localhost:9001/${lang}`)
    .then(res => res.text())
    .then(msg => {
      const wrapper = document.createElement("div");
      wrapper.className = "message";

      const text = document.createElement("div");
      text.innerText = msg;
      wrapper.appendChild(text);

      const btn = document.createElement("button");
      btn.innerText = "Show Code";
      btn.onclick = () => {
        const codeDiv = document.getElementById(`code-${lang}`);
        codeDiv.style.display = codeDiv.style.display === "none" ? "block" : "none";
      };
      wrapper.appendChild(btn);

      const code = document.createElement("pre");
      code.className = "code-block";
      code.id = `code-${lang}`;
      code.innerText = "// Loading...";
      code.style.display = "none";
      wrapper.appendChild(code);

      fetch(`/snippets/${lang}.txt`)
        .then(res => res.text())
        .then(codeText => {
          code.innerText = codeText;
        })
        .catch(() => {
          code.innerText = "// Code snippet not found.";
        });

      messagesDiv.appendChild(wrapper);
    })
    .catch(err => {
      const div = document.createElement("div");
      div.className = "message";
      div.innerText = `${lang.toUpperCase()} failed to load.`;
      messagesDiv.appendChild(div);
    });
});
