local socket = require("socket")
local server = socket.bind("*", 9012)
while 1 do
  local client = server:accept()
  client:receive("*l")
  client:send("HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nHello World from Lua")
  client:close()
end